# ADR-0002: Validator Safety — BFT Parameters (N=5, f=1)

**Status:** Accepted (Genesis)  
**Date:** 2025-12-18 (Dubai)  
**Scope:** Genesis / Phase 0–1 local cluster

## Decision
- N = 5 validators
- f = 1 faulty validator tolerated
- Quorum Q = 2f + 1 = 3

## Rationale
Safety condition: N ≥ 3f + 1.
If N = 5 ⇒ f ≤ 1.
