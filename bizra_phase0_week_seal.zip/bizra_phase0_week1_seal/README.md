# Phase 0 Week 1 — Seal & Gate Pack

This pack makes your model fleet deterministic across **Ollama + LM Studio**.

## Run
powershell -ExecutionPolicy Bypass -File scripts\audit-model-family-dual.ps1

## Then
Fill UNKNOWN_SHA256 / AUDIT_FILL in:
- manifests/model-family.artifacts.v1.yaml
Mark sealed=true, commit + tag.
