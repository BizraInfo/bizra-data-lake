\
$OutDir = "evidence\model_family"
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

# Ollama
try { "COMMAND: ollama list" | Out-File "$OutDir\ollama_list.txt"; ollama list | Out-File "$OutDir\ollama_list.txt" -Append } catch {}

# LM Studio models
$LmBase = "http://127.0.0.1:1234"
try {
  $models = Invoke-RestMethod -Uri "$LmBase/v1/models" -Method GET -TimeoutSec 5
  $models | ConvertTo-Json -Depth 8 | Out-File "$OutDir\lmstudio_models.json"
} catch {}

# Best-effort hash scan (common LM Studio dirs)
$Candidates = @(
  Join-Path $env:USERPROFILE ".lmstudio\models",
  Join-Path $env:LOCALAPPDATA "LMStudio\models",
  Join-Path $env:APPDATA "LMStudio\models"
)
$hashes = @()
foreach ($dir in $Candidates) {
  if (Test-Path $dir) {
    Get-ChildItem $dir -Recurse -File -ErrorAction SilentlyContinue |
      Where-Object { $_.Name -match "\.gguf$|\.bin$|\.safetensors$" } |
      ForEach-Object {
        try {
          $h = Get-FileHash -Algorithm SHA256 -Path $_.FullName
          $hashes += [pscustomobject]@{ path=$_.FullName; sha256=$h.Hash.ToLower(); size_bytes=$_.Length }
        } catch {}
      }
  }
}
$hashes | ConvertTo-Json -Depth 4 | Out-File "$OutDir\lmstudio_file_hashes.json"

Write-Host "Audit done. Collect:" -ForegroundColor Yellow
Write-Host "  - evidence/model_family/ollama_list.txt"
Write-Host "  - evidence/model_family/lmstudio_models.json"
Write-Host "  - evidence/model_family/lmstudio_file_hashes.json"
